// Tableau contenant des chaines de caractères correspondant aux recherches stockées
var recherches = [];
// Chaine de caractères correspondant à la recherche courante
var recherche_courante;
// Tableau d'objets de type resultats (avec titre, date et url)
var recherche_courante_news = []; 


function ajouter_recherche() {
	//TODO ...
}


function supprimer_recherche(e) { 
	//TODO ...
}


function selectionner_recherche(e) { 
	//TODO ...
}


function init() {
	//TODO ...
}


function rechercher_nouvelles() {
	//TODO ...
}


function maj_resultats(res) {
	//TODO ...
}


function sauver_nouvelle(e) {
	//TODO ...
}


function supprimer_nouvelle(e) {
	//TODO ...
}

